<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateUsersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('users', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('user_name', 50)->nullable()->default('0')->comment('nombre de usuario');
			$table->string('user_pass', 50)->nullable()->default('0');
			$table->integer('id_user_type')->default(0)->index('FK_usuarios_tiposdeusuarios');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('users');
	}

}
